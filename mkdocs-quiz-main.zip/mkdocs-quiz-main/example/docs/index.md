# Quiz Example

## Single choice

<?quiz?>

question: Are you ready?
answer-correct: Yes!
answer: No!
answer: Maybe!
content:

<h2>Provide some additional content</h2>
<?/quiz?>

## Multiple choice

<?quiz?>

question: Are you ready?
answer-correct: Yes!
answer: No!
answer-correct: Maybe!
content:

<h2>Provide some additional content</h2>
<?/quiz?>

## Disable for a page

See [disable.md](disable.md) for an example.
