---
quiz: disable
---

# Disabled Quiz

All quizzes are disabled for this page, so you will just see the markdown code.

```markdown
<?quiz?>

question: Are you ready?
answer-correct: Yes!
answer: No!
answer-correct: Maybe!
content:

<h2>Provide some additional content</h2>
<?/quiz?>
```
